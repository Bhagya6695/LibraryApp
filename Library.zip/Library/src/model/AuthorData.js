//Access mongoose
const mongoose = require('mongoose');

//connecting server side with db
mongoose.connect('mongodb://localhost:27017/library');

//schema definition
// const Book = require('./Bookdata');
//creating schema for a single Author
const Schema = mongoose.Schema;


const AuthorSchema = new Schema({
    name : String,
    book : String,
    genre : String,
    image : {
        data:Buffer,
        contentType:String}
})
    
//Model creation
var AuthorData = mongoose.model('authordata',AuthorSchema);


module.exports = AuthorData;