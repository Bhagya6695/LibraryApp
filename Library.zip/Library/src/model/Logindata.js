//Access mongoose
const mongoose = require('mongoose');

//connecting server side with db
mongoose.connect('mongodb://localhost:27017/library');

//schema definition
const Schema = mongoose.Schema;


const LoginSchema = new Schema({
    username : String,
    password : String,
})
    
//Model creation
var Logindata = mongoose.model('logindata',LoginSchema);


module.exports = Logindata;