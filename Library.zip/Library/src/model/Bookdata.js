//Access mongoose
const mongoose = require('mongoose');

//connecting server side with db
mongoose.connect('mongodb://localhost:27017/library');

//schema definition
const Schema = mongoose.Schema;
//creating schema for a single Book


const BookSchema = new Schema({
    title : String,
    author : String,
    genre : String,
    image : String
}
);


    
//Model creation
var Bookdata = mongoose.model('bookdata',BookSchema);


module.exports = Bookdata;
