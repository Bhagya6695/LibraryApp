//Access mongoose
const mongoose = require('mongoose');

//connecting server side with db
mongoose.connect('mongodb://localhost:27017/library');


const Schema = mongoose.Schema;


const SignupSchema = new Schema({
    name : String,
    email : String,
    phone : Number,
    password : String,
    cpassword : String
});
    
//Model creation
var User = mongoose.model('user',SignupSchema);


module.exports = User;