const express = require("express");
const addauthorRouter =  express.Router();
const AuthorData = require('../model/AuthorData')


function router(nav){
     
    addauthorRouter.get('/', function(req, res){
        res.render('addauthor',{
            nav,
            title:'Add Author'
        });
    });
    
   


addauthorRouter.post('/AddAuthor', function(req, res){
    var item = {
    name : req.body.name,
    book : req.body.book,
   genre : req.body.genre,
   image : req.body.image
    }
    var author = AuthorData(item);
    author.save();
    res.redirect('/authors');
});

    return addauthorRouter;
    
}

module.exports = router;


