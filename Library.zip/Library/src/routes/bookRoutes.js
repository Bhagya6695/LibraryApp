const express = require("express");
const booksRouter =  express.Router();
const Bookdata = require('../model/Bookdata');

function router(nav){
    booksRouter.get('/',function(req,res){
        Bookdata.find()
        .then(function(books){
            res.render("books",
        {
            nav,
            title:'Books',
            books
        });
        })
        
    });
    
    booksRouter.get('/:id',function(req,res){
        const id = req.params.id;
        Bookdata.findOne({_id:id})
        .then(function(book){
            res.render("book",
        {
            nav,
            title:'Book',
            book
        });
        })
        
    });

    
    
    booksRouter.get('/:id/update', function(req, res){
        
        const id = req.params.id;
        Bookdata.findOne({_id:id})
        .then(function(book){
            res.render("updatebook",
        {
            nav,
            title:'Update',
            book
        });
        })
        
    });

    
    booksRouter.post('/:id/update/upload', function(req, res){
        const id = req.params.id;
        var item={
           title :req.body.title,
            author : req.body.author,
            genre :req.body.genre,
            image : req.body.image

        };
        var img = req.body.image;
        if((req.body.image)==null){
            img = req.body.image;
        }
        var book = Bookdata(item);
        Bookdata.findByIdAndUpdate({_id:id},req.body,{new:true},)
        .then(function(book){
            res.redirect('/books');
        });
    });

   
   booksRouter.get('/:id/delete',function(req,res){
        const id = req.params.id;
        Bookdata.findByIdAndDelete({_id:id})
        .then(function(book){
            res.redirect('/books');
        });
    });

    return booksRouter;
    
}



module.exports = router;