const express = require("express");
const authorRouter =  express.Router();
const Authordata = require('../model/AuthorData');
const Bookdata = require("../model/Bookdata");

function router(nav){
    // var authors = [
    //     {
    //         name: 'Andrew Mayne',
    //         book:'The Naturalist',
    //         genre: 'Fiction',
    //         img :'andrew.jpeg'
    
    //     },
    //     {
    //         name: 'Dan Brown',
    //         book:'The Davinci Code',
    //         genre: 'Thriller & Mystery',
    //         img :'dan.jpeg'
    
    //     },
    //     {
    //         name: 'Ken Follett',
    //         book:'The Pillars Of The Earth',
    //         genre: 'Thriller & Historical-Fiction',
    //         img :'ken.jpeg'
    
    //     },
    //     {
    //         name: 'James Caroll',
    //         book:'The Cloister',
    //         genre: 'Fiction & History',
    //         img :'james.jpeg'
    
    //     },
    //     {
    //         name: 'K.R Meera',
    //         book:'Aarachar',
    //         genre: 'Novel & Short-story',
    //         img :'meera.jpeg'
    
    //     }
    // ]
    
    
    authorRouter.get('/',function(req,res){
        Authordata.find()
        .then(function(authors){
            res.render("authors",
            {
                nav,
                title:'Authors',
                authors
            });
        })
       
    });
    
    authorRouter.get('/:id',function(req,res){
        const id = req.params.id;
        Authordata.findOne({_id:id})
        .then(function(author){
            res.render("author",
            {
                nav,
                title:'Author',
                author
            });
        })
      
    });

    authorRouter.get('/:id/update', function(req, res){
        
        const id = req.params.id;
        Authordata.findOne({_id:id})
        .then(function(author){
            res.render("updateauthor",
        {
            nav,
            title:'Update',
            author
        });
        })
        
    });

    authorRouter.post('/:id/update/upload', function(req, res){
        const id = req.params.id;
        var item={
           name :req.body.name,
            book : req.body.book,
            genre :req.body.genre,
            image : req.body.image

        };
        var author = Authordata(item);
             Authordata.findByIdAndUpdate({_id:id},req.body,{new:true})
        .then(function(author){
            res.redirect('/authors');
        });
    });


    authorRouter.get('/:id/delete',function(req,res){
        const id = req.params.id;
        Authordata.findByIdAndDelete({_id:id})
        .then(function(author){
            res.redirect('/authors');
        });
    });


    return authorRouter;
    
}



module.exports = router;