var name = document.getElementById("name");
var authors = document .getElementById("author");
var genre = document . getElementById("genre");
var fname = document.getElementById("fname");
var lname = document.getElementById("lname");
var email = document.getElementById("email");
var comment = document.getElementById("comment");




function validate(){
    if (name.value==""||authors.value==""||genre.value==""){
        alert("Please fill all fields!!!");
        return false;
    }
    else{
        return true;
    }
}

function validatecontacts()
{
    if (fname.value==""||lname.value==""||email.value==""||comment.value==""){
        alert("Please fill your valuable suggestion!!");
        return false;
    }
    else{
        return true;
    }

}